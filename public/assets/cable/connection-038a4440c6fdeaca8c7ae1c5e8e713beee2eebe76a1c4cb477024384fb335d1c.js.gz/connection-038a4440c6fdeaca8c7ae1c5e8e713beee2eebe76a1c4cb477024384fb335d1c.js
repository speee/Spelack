(function() {
  var message_types,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    slice = [].slice,
    indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

  message_types = Cable.INTERNAL.message_types;

  Cable.Connection = (function() {
    Connection.reopenDelay = 500;

    function Connection(consumer) {
      this.consumer = consumer;
      this.open = bind(this.open, this);
      this.open();
    }

    Connection.prototype.send = function(data) {
      if (this.isOpen()) {
        this.webSocket.send(JSON.stringify(data));
        return true;
      } else {
        return false;
      }
    };

    Connection.prototype.open = function() {
      if (this.webSocket && !this.isState("closed")) {
        throw new Error("Existing connection must be closed before opening");
      } else {
        this.webSocket = new WebSocket(this.consumer.url);
        this.installEventHandlers();
        return true;
      }
    };

    Connection.prototype.close = function() {
      var ref;
      return (ref = this.webSocket) != null ? ref.close() : void 0;
    };

    Connection.prototype.reopen = function() {
      if (this.isState("closed")) {
        return this.open();
      } else {
        try {
          return this.close();
        } finally {
          setTimeout(this.open, this.constructor.reopenDelay);
        }
      }
    };

    Connection.prototype.isOpen = function() {
      return this.isState("open");
    };

    Connection.prototype.isState = function() {
      var ref, states;
      states = 1 <= arguments.length ? slice.call(arguments, 0) : [];
      return ref = this.getState(), indexOf.call(states, ref) >= 0;
    };

    Connection.prototype.getState = function() {
      var ref, state, value;
      for (state in WebSocket) {
        value = WebSocket[state];
        if (value === ((ref = this.webSocket) != null ? ref.readyState : void 0)) {
          return state.toLowerCase();
        }
      }
      return null;
    };

    Connection.prototype.installEventHandlers = function() {
      var eventName, handler;
      for (eventName in this.events) {
        handler = this.events[eventName].bind(this);
        this.webSocket["on" + eventName] = handler;
      }
    };

    Connection.prototype.events = {
      message: function(event) {
        var identifier, message, ref, type;
        ref = JSON.parse(event.data), identifier = ref.identifier, message = ref.message, type = ref.type;
        switch (type) {
          case message_types.confirmation:
            return this.consumer.subscriptions.notify(identifier, "connected");
          case message_types.rejection:
            return this.consumer.subscriptions.reject(identifier);
          default:
            return this.consumer.subscriptions.notify(identifier, "received", message);
        }
      },
      open: function() {
        this.disconnected = false;
        return this.consumer.subscriptions.reload();
      },
      close: function() {
        return this.disconnect();
      },
      error: function() {
        return this.disconnect();
      }
    };

    Connection.prototype.disconnect = function() {
      if (this.disconnected) {
        return;
      }
      this.disconnected = true;
      return this.consumer.subscriptions.notifyAll("disconnected");
    };

    Connection.prototype.toJSON = function() {
      return {
        state: this.getState()
      };
    };

    return Connection;

  })();

}).call(this);
